

Plugin Name: Ultraschall Icons 3.1<br>
Plugin URI: http://ultraschall.fm<br>
Description: Create easy shortcode for Ultraschall website<br>
Version: 1.0.0.2<br>
Author: Michael McCouman Junior<br>
Author URI: http://wikibyte.org<br>
Copyright: Ultraschall Project<br>
Text Domain: usi<br>


Beispiel: `[usi icon="ultraschall" color="#f00" size="50"]`

    [usi icon="ultraschall"]
    [usi icon="soundboard"] //dummy!
    [usi icon="studio-link"]
    [usi icon="zoom"]
    [usi icon="ripple_one"]
    [usi icon="ripple_all"]
    [usi icon="glue"]
    [usi icon="marker"]
    [usi icon="cut"]
    [usi icon="mouse_select"]
    [usi icon="selection"]
    [usi icon="mute"]
    [usi icon="fader"]
    [usi icon="tape"]
    [usi icon="trim"]
    [usi icon="idea"]
    [usi icon="music"]
    [usi icon="mic"]
    [usi icon="coffee"]
    [usi icon="onAir"]
    [usi icon="grid"]
    [usi icon="export"]
    [usi icon="mp3"]
    [usi icon="folder"]
    [usi icon="link"]
    [usi icon="unlink"]
    [usi icon="txtlable"]
    [usi icon="txt"]
    [usi icon="newitem"]
    [usi icon="newregion"]
    [usi icon="ultraschall-full"]
